export default function OurTeam() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Our Team</h1>
      <p className="text-gray-700">Meet the amazing team behind our cool project.</p>
    </div>
  )
}
